Zimbabwe Tree Key – Field Edition 1.2

The new Matabeleland ID Key is an interactive elimination key:
1. leaf type
2. thorns/spines
3. habitat
4. bark
5. fruit

It returns a short list of candidate trees rather than pretending to make a certain
identification from limited observations.

The source-backed Matobo and Bulawayo locality information has also been retained.
For example, Flora of Zimbabwe records Brachystegia glaucescens at Besna Kobila and
Camp Dwala in the Matobo Hills and in the Bulawayo south area, and records Ehretia
rigida from Shumbashaba in the Matobo Hills with two photographs by Meg Coates Palgrave.

Photographic source pages remain linked rather than copied into the package.
